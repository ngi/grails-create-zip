
class CreateZipTagLib {

	def downloadzipdirectory = { attrs, body ->
		def zipDir = attrs.remove('srcdir')
		def zipFile = attrs.remove('zipfile')
		def zipurl = attrs.remove('zipurl')
		
		ZipFile.leftShift(zipFile, zipDir)

		/* html */
		def charset = attrs.remove('charset') 	
		def coords = attrs.remove('coords')	
		def hreflang = attrs.remove('hreflang') 	
		def name = attrs.remove('name')  	
		def rel = attrs.remove('rel') 
		def rev = attrs.remove('rev') 
		def shape = attrs.remove('shape') 
		def target = attrs.remove('target') 
		
		/* html */
		def accesskey = attrs.remove('accesskey')	
		def cssclass = attrs.remove('class') 	
		def dir = attrs.remove('dir')	
		def ltr = attrs.remove('ltr')	
		def elmid = attrs.remove('id')
		def lang = attrs.remove('lang') 	
		def style = attrs.remove('style') 	
		def tabindex = attrs.remove('tabindex') 	
		def title = attrs.remove('title') 
		def xml_lang = attrs.remove('xml:lang') 	
		
		/* Standard img tag event attributes */
		def onclick = attrs.remove('onclick')
		def ondblclick = attrs.remove('ondblclick')
		def onmousedown = attrs.remove('onmousedown')
		def onmoouseup = attrs.remove('onmoouseup')
		def onmouseover = attrs.remove('onmouseover')
		def onmousemove = attrs.remove('onmousemove')
		def onmouseout = attrs.remove('onmouseout')
		def onkeypress = attrs.remove('onkeypress')
		def onkeydown = attrs.remove('onkeydown')
		def onkeyup = attrs.remove('onkeyup')
		
		def parameters = "href=\"" + zipurl +"\""
		
		parameters += onclick ? " onclick=\""+onclick+"\"" : ""
		parameters += ondblclick ? " ondblclick=\""+ondblclick+"\"" : ""
		parameters += onmousedown ? " onmousedown=\""+onmousedown+"\"" : ""
		parameters += onmoouseup ? " onmoouseup=\""+onmoouseup+"\"" : ""
		parameters += onmouseover ? " onmouseover=\""+onmouseover+"\"" : ""
		parameters += onmousemove ? " onmousemove=\""+onmousemove+"\"" : ""
		parameters += onmouseout ? " onmouseout=\""+onmouseout+"\"" : ""
		parameters += onkeypress ? " onkeypress=\""+onkeypress+"\"" : ""
		parameters += onkeydown ? " onkeydown=\""+onkeydown+"\"" : ""
		parameters += onkeyup ? " onkeyup=\""+onkeyup+"\"" : ""
		
		parameters += charset ? " charset=\""+charset+"\"" : ""
		parameters += coords ? " coords=\""+coords+"\"" : ""
		parameters += hreflang ? " hreflang=\""+hreflang+"\"" : ""
		parameters += name ? " name=\""+name+"\"" : ""
		parameters += rel ? " rel=\""+rel+"\"" : ""
		parameters += rev ? " rev=\""+rev+"\"" : ""
		parameters += shape ? " shape=\""+shape+"\"" : ""
		parameters += target ? " target=\""+target+"\"" : ""

		parameters += accesskey ? " accesskey=\""+accesskey+"\"" : ""
		parameters += cssclass ? " class=\""+cssclass+"\"" : ""
		parameters += dir ? " dir=\""+dir+"\"" : ""
		parameters += ltr ? " ltr=\""+ltr+"\"" : ""
		parameters += elmid ? " id=\""+elmid+"\"" : ""
		parameters += lang ? " lang=\""+lang+"\"" : ""
		parameters += style ? " style=\""+style+"\"" : ""
		parameters += tabindex ? " tabindex=\""+tabindex+"\"" : ""
		parameters += title ? " title=\""+title+"\"" : ""
		parameters += xml_lang ? " xml:lang=\""+xml_lang+"\"" : ""
		
        out << "<a "+parameters+">"+ body() +"</a>"
	}
}


class CreateZipTagLib {

	def zipdirectory = { attrs, body ->
		def zipDir = attrs.remove('srcdir')
		def zipFileName = attrs.remove('zipfile')
		
		def params
		
		params['dir'] = zipDir
        params['filename'] = zipFileName
		
		out << g.link(controller: "zip",
			action: "directory",  params: params)
	}
}

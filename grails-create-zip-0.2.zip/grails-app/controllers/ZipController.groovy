

class ZipController {

	def createzip = {
		def directory = params['dir']
		def filename = params['filename']
		response.setContentType("application/zip")
		// response.setContentLength(svgSchemaAnatomicoInstance?.jpgdata.size())
		response.setHeader('filename', filename)
		ZipFile.leftShift(response.outputStream, directory)
	}

}
